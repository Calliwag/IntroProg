The AY sound support is based on public domain zxssk library
"created under public domain license by SMT, jan.2006"
